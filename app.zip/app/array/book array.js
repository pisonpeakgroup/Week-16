﻿var books = ['Book1', 'Book2', 'Book3', 'Book4', 'Book5', 'Book6', 'Book7', 'Book8', 'Book9', 'Book10',];

console.log(books.length);
console.log(book.from);