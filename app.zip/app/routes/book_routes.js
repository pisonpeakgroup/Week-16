// book_routes.js
module.exports = function(app, db) {
  app.post('/book', (req, res) => {
    // My book is here.
    res.send('Hello this is BookLab')
    // A request on the home route to retrieve data
app.get('/Home', function (req, res) {
  res.send('Welcome to the book Store, Your Specified ID generated these Books!')
})
// Respond to POST request on the root route (/Home), the application’s home page:

app.post('/About', function (req, res) {
  res.send('We have gotten an array of books, check them below')
})
// Respond to a PUT request to the /user route:

app.put('/client1', function (req, res) {
  res.send('Kindly update a book with your given ID  /client1')
})
// Respond to a DELETE request to the /user route:

app.delete('/client1', function (req, res) {
  res.send('Kindly DELETE a book as necessary with a specified ID  /client1')
})
  });
};