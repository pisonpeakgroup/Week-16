/ routes/index.js
const bookRoutes = require('./book_routes');
module.exports = function(app, db) {
  bookRoutes(app, db);
  // Other route groups could go here, in the future
  const note = { text: req.body.body, title: req.body.title}
  db.collection('notes').insert(note, (err, results) => {
}
};
